const jobType = document.getElementById("jobType");
const generalFields = document.getElementById("generalFields");
const form = document.getElementById("serviceForm");
const feedback = document.getElementById("feedback");

function updateGeneralVisibility() {
  if (jobType.value === "general") {
    generalFields.classList.remove("hidden");
  } else {
    generalFields.classList.add("hidden");
  }
}

jobType.addEventListener("change", updateGeneralVisibility);
updateGeneralVisibility();

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  feedback.textContent = "Submitting...";

  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const res = await fetch("/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    if (json.status === "success") {
      feedback.textContent =
        "Submitted successfully! — " +
        (json.received.vehicleNo || "") +
        " / " +
        (json.received.vehicleModel || "");
      form.reset();
      updateGeneralVisibility();
    } else {
      feedback.textContent = "Submission failed";
    }
  } catch (err) {
    console.error(err);
    feedback.textContent = "Error submitting: " + err.message;
  }
});
